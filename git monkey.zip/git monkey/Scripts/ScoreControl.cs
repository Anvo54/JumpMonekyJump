﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreControl : MonoBehaviour {

    public Transform player;

    public Text scoreText;
    public Text hiScoreText;

    public int score;
    public int hiScore = 0;

    //public float pointsPerDistance;
	
	void Start ()
    {
        score = 0;
        if(PlayerPrefs.HasKey("Highscore") == true)
        {
            hiScoreText.text = PlayerPrefs.GetInt("Hiscore").ToString();

        }else{
            hiScoreText.text = "0";
        }
        //UpdateScore(); 
        
        /*if(PlayerPrefs.HasKey("Highscore"))
        {
            hiScoreText.text = PlayerPrefs.GetInt("Highscore", 0).ToString();
        }*/
	}
	
	
	void Update ()
    {
        //scoreText.text = "Score: " + player.position.y.ToString("0");
        UpdateScore();
        
    }

    void UpdateScore()
    {
        scoreText.text = ("Score: " + player.position.y.ToString("0"));
        if (PlayerPrefs.GetInt("highestscore", 0) < score)
            PlayerPrefs.SetInt("highestscore", score);
        hiScoreText.text = "Highscore: " + PlayerPrefs.GetInt("highestscore", 0);
    }

    public void SetHighScore()
    {
        PlayerPrefs.SetInt("Highscore", score);
        hiScoreText.text = PlayerPrefs.GetInt("Highscore").ToString("0");
    }
}
