﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour
{
    //public GameObject kong;

    public float speedUp = 10f;
    public float duration = 5f;

    

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("monkey"));
        {
            StartCoroutine(PickUp(other));
            
        }
    }

    

    IEnumerator PickUp(Collider2D monkey)
    {
        monkey kong = monkey.GetComponent<monkey>();
        kong.speed *= speedUp;

        GetComponent<SpriteRenderer>().enabled = false;
        GetComponent<Collider2D>().enabled = false;
        

        yield return new WaitForSeconds(duration);

        kong.speed /= speedUp;
        Destroy(gameObject);
    }
}
